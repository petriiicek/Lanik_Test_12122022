﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanikTestDB
{
    public partial class FormEditing : Form
    {
        SqlRepository sqlRepository = new SqlRepository();
        Form1 form1 = new Form1();
        public FormEditing()
        {
            InitializeComponent();
        }
        public void LoadData(string id, string fullname, string phone, string email, DateTime birthday)
        {
            label3.Text = id;
            textBoxFullname.Text = fullname;
            textBoxPhone.Text = phone;
            textBoxEmail.Text = email;
            inputBirtday.Value = birthday;
        }
        private void buttonEditComplete_Click(object sender, EventArgs e)
        {
            sqlRepository.EditEmployee(label3.Text, textBoxFullname.Text, textBoxPhone.Text, textBoxEmail.Text, Convert.ToDateTime(inputBirtday.Value));
            this.Close();
            Form1 form1 = new Form1();
            form1.Show();
        }

        private void buttonEditClose_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 form1 = new Form1();
            form1.Show();
        }
    }
}
