﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanikTestDB
{
    public partial class Form1 : Form
    {
        List<Employee> employees;
        SqlRepository sqlRepository = new SqlRepository();
        public Form1()
        {
            InitializeComponent();
            employees = sqlRepository.GetEmployees();
            RefreshGUI();
        }
        public void RefreshGUI()
        {
            listView1.Items.Clear();
            foreach (Employee employee in employees)
            {
                ListViewItem listViewItem = new ListViewItem(new string[] {
                    employee.Id.ToString(),
                    employee.Fullname.ToString(),
                    employee.Email.ToString(),
                    employee.Phone.ToString(),
                    employee.Birthday.ToString("dd.MM.yyyy")
                });
                listView1.Items.Add(listViewItem);
                listView1.Refresh();
            }
        }

        private void buttonInsert_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormInsert formInsert = new FormInsert();
            formInsert.Show();
        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count == 0)
            {
                MessageBox.Show("Not selected row");
            }
            else
            {
                this.Hide();
                FormEditing formEditing = new FormEditing();
                formEditing.Show();
                var selectedRow = listView1.SelectedItems[0];
                var id = selectedRow.SubItems[0].Text;
                var fullname = selectedRow.SubItems[1].Text;
                var email = selectedRow.SubItems[2].Text;
                var phone = selectedRow.SubItems[3].Text;
                var birthday = selectedRow.SubItems[4].Text;
                formEditing.LoadData(id, fullname, phone, email, Convert.ToDateTime(birthday));
            }
        }

        private void buttonRemove_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count == 0)
            {
                MessageBox.Show("Row isn't selected");
            }
            else
            {
                var selectedRow = listView1.SelectedItems[0];
                var idValue = selectedRow.SubItems[0].Text;
                sqlRepository.DeleteEmployees(idValue);
                listView1.SelectedItems[0].Remove();
            }
        }
    }
}
