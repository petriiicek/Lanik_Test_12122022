﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12122022_Lanik_test
{
    internal class Employee
    {
    }
}
